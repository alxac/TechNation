﻿namespace TechNation.Data.Repositorio
{
    public interface ILogRepositorio
    {
    }
}
